package capa_logica;
import capa_grafica.Fondo;
import javax.swing.*;
import java.util.Scanner;
public class Final {
    public static void main(String[] args){
        
        
        
        JFrame frameFondo = new Fondo();//EL frame
        frameFondo.show();
    }
}
